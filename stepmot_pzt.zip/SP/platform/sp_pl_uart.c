#include"sp_pl_uart.h"

//串口配置
extern UART_HandleTypeDef huart1;
#define SP_UART huart1
#define SP_UART_MAX_TX_LEN 128
#define SP_UART_MAX_RX_LEN 128

//串口数据
typedef struct sp_uart_data_t
{
    u8 tx_data[SP_UART_MAX_TX_LEN];
    u8 rx_data[SP_UART_MAX_RX_LEN];
    u16 rx_len;
}sp_uart_data_t;
static sp_uart_data_t sp_uart_data={0};

//串口发送
void sp_uart_tx(char*data,...);
//串口直接发送
void sp_uart_tx_dir(u8*data,u16 len);
//串口接收
char*sp_uart_rx();
//串口直接接收
void sp_uart_rx_dir(u8**data,u16*len);
//串口超时接收
char*sp_uart_rx_time(u16 time);

//串口发送
void sp_uart_tx(char*data,...)
{
    //等待发送空闲
    while(SP_UART.gState!=HAL_UART_STATE_READY)
    {
        // SP_LOG("uart wait\n");
        osDelay(1);
    }
    //更新发送缓冲区
    memset(sp_uart_data.tx_data,0,SP_UART_MAX_TX_LEN);
    va_list val;
    va_start(val,data);
    vsnprintf((char*)sp_uart_data.tx_data,SP_UART_MAX_TX_LEN,data,val);
    va_end(val);
    //DMA发送
    HAL_UART_Transmit_DMA(&SP_UART,(u8*)sp_uart_data.tx_data,strlen((char*)sp_uart_data.tx_data));
}

//串口直接发送
void sp_uart_tx_dir(u8*data,u16 len)
{
    //等待发送空闲
    while(SP_UART.gState!=HAL_UART_STATE_READY)
    {
        // SP_LOG("uart wait\n");
        osDelay(1);
    }
    //DMA发送
    HAL_UART_Transmit_DMA(&SP_UART,data,len);
}

//串口接收
char*sp_uart_rx()
{
    //更新接收缓冲区
    memset(sp_uart_data.rx_data,0,SP_UART_MAX_RX_LEN);
    //等待接收数据
    HAL_UARTEx_ReceiveToIdle_DMA(&SP_UART,sp_uart_data.rx_data,SP_UART_MAX_RX_LEN);
    while(SP_UART.RxState!=HAL_UART_STATE_READY)
    {
        osDelay(1);
    }
    return (char*)sp_uart_data.rx_data;
}

//串口直接接收
void sp_uart_rx_dir(u8**data,u16*len)
{
    //更新接收缓冲区
    memset(sp_uart_data.rx_data,0,SP_UART_MAX_RX_LEN);
    //等待接收数据
    HAL_UARTEx_ReceiveToIdle_DMA(&SP_UART,sp_uart_data.rx_data,SP_UART_MAX_RX_LEN);
    while(SP_UART.RxState!=HAL_UART_STATE_READY)
    {
        osDelay(1);
    }
    *data=sp_uart_data.rx_data;
    *len=sp_uart_data.rx_len;
}

//串口超时接收
char*sp_uart_rx_time(u16 time)
{
    //更新接收缓冲区
    memset(sp_uart_data.rx_data,0,SP_UART_MAX_RX_LEN);
    //等待接收数据
    HAL_UARTEx_ReceiveToIdle_DMA(&SP_UART,sp_uart_data.rx_data,SP_UART_MAX_RX_LEN);
    u16 time_=0;
    while(SP_UART.RxState!=HAL_UART_STATE_READY)
    {
        if(time_>time)
        {
            return NULL;
        }
        ++time_;
        osDelay(1);
    }
    return (char*)sp_uart_data.rx_data;
}


//平台串口1配置
extern UART_HandleTypeDef huart2;
#define SP_PL_UART1 huart2
#define SP_PL_UART1_MAX_TX_LEN 128
#define SP_PL_UART1_MAX_RX_LEN 128

//平台串口1数据
typedef struct sp_pl_uart1_data_t
{
    u8 tx_data[SP_PL_UART1_MAX_TX_LEN];
    u8 rx_data[SP_PL_UART1_MAX_RX_LEN];
    u16 rx_len;
}sp_pl_uart1_data_t;
static sp_pl_uart1_data_t sp_pl_uart1_data={0};

//平台串口1发送
void sp_pl_uart1_tx(char*data,...);
//平台串口1直接发送
void sp_pl_uart1_tx_dir(u8*data,u16 len);
//平台串口1接收
char*sp_pl_uart1_rx();
//平台串口1直接接收
void sp_pl_uart1_rx_dir(u8**data,u16*len);
//平台串口1超时接收
char*sp_pl_uart1_rx_time(u16 time);

//平台串口1发送
void sp_pl_uart1_tx(char*data,...)
{
    //等待发送空闲
    while(SP_PL_UART1.gState!=HAL_UART_STATE_READY)
    {
        // SP_LOG("uart wait\n");
        osDelay(1);
    }
    //更新发送缓冲区
    memset(sp_pl_uart1_data.tx_data,0,SP_PL_UART1_MAX_TX_LEN);
    va_list val;
    va_start(val,data);
    vsnprintf((char*)sp_pl_uart1_data.tx_data,SP_PL_UART1_MAX_TX_LEN,data,val);
    va_end(val);
    //DMA发送
    HAL_UART_Transmit_DMA(&SP_PL_UART1,(u8*)sp_pl_uart1_data.tx_data,strlen((char*)sp_pl_uart1_data.tx_data));
}

//平台串口1直接发送
void sp_pl_uart1_tx_dir(u8*data,u16 len)
{
    //等待发送空闲
    while(SP_PL_UART1.gState!=HAL_UART_STATE_READY)
    {
        // SP_LOG("uart wait\n");
        osDelay(1);
    }
    //DMA发送
    HAL_UART_Transmit_DMA(&SP_PL_UART1,data,len);
}

//平台串口1接收
char*sp_pl_uart1_rx()
{
    //更新接收缓冲区
    memset(sp_pl_uart1_data.rx_data,0,SP_PL_UART1_MAX_RX_LEN);
    //等待接收数据
    HAL_UARTEx_ReceiveToIdle_DMA(&SP_PL_UART1,sp_pl_uart1_data.rx_data,SP_PL_UART1_MAX_RX_LEN);
    while(SP_PL_UART1.RxState!=HAL_UART_STATE_READY)
    {
        osDelay(1);
    }
    return (char*)sp_pl_uart1_data.rx_data;
}

//平台串口1直接接收
void sp_pl_uart1_rx_dir(u8**data,u16*len)
{
    //更新接收缓冲区
    memset(sp_pl_uart1_data.rx_data,0,SP_PL_UART1_MAX_RX_LEN);
    //等待接收数据
    HAL_UARTEx_ReceiveToIdle_DMA(&SP_PL_UART1,sp_pl_uart1_data.rx_data,SP_PL_UART1_MAX_RX_LEN);
    while(SP_PL_UART1.RxState!=HAL_UART_STATE_READY)
    {
        osDelay(1);
    }
    *data=sp_pl_uart1_data.rx_data;
    *len=sp_pl_uart1_data.rx_len;
}

//平台串口1超时接收
char*sp_pl_uart1_rx_time(u16 time)
{
    //更新接收缓冲区
    memset(sp_pl_uart1_data.rx_data,0,SP_PL_UART1_MAX_RX_LEN);
    //等待接收数据
    HAL_UARTEx_ReceiveToIdle_DMA(&SP_PL_UART1,sp_pl_uart1_data.rx_data,SP_PL_UART1_MAX_RX_LEN);
    u16 time_=0;
    while(SP_PL_UART1.RxState!=HAL_UART_STATE_READY)
    {
        if(time_>time)
        {
            return NULL;
        }
        ++time_;
        osDelay(1);
    }
    return (char*)sp_pl_uart1_data.rx_data;
}

//串口接收回调函数
void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef*huart,uint16_t len);

//串口接收回调函数
void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef*huart,uint16_t len)
{
    if(huart->Instance==SP_UART.Instance)
    {
        sp_uart_data.rx_len=len;
    }else
    if(huart->Instance==SP_PL_UART1.Instance)
    {
        sp_pl_uart1_data.rx_len=len;
    }
}
