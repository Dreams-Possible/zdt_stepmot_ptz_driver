#include"sp_app.h"
#include"stepmot_pzt.h"
#include<math.h>

//用户应用
void sp_app();

//用户应用
void sp_app()
{
	SP_LOG("init\n");

    SP_LOG("init ok\n");

    
    
    // while(1)
    // {
    //     sp_uart_tx("start\n");
    //     //从串口输入
    //     u8*data=NULL;
    //     u16 len=0;
    //     //串口直接接收
    //     // data=sp_uart_rx();
    //     sp_uart_rx_dir(&data,&len);
    //     // sp_uart_tx("len=%d\n",len);
    //     // sp_uart_tx("data=%s\n",data);
    //     //串口直接发送
    //     // sp_uart_tx(data);
    //     sp_uart_tx_dir(data,len);
    //     osDelay(10);
    // }

    // while(1)
    // {
    //     osDelay(100);
    // }



    // //电机初始化
    // zdt_stepmot_init_ad1();
    // while(1)
    // {
    //     if(!zdt_stepmot_check_ad1())
    //     {
    //         //电机设置
    //         sp_uart_tx("st1\n");
    //         zdt_stepmot_set_ad1(1,400,800);
    //         sp_uart_tx("st2\n");
    //         zdt_stepmot_set_ad1(0,400,800);
    //     }else
    //     {
    //         sp_uart_tx("busy\n");
    //     }
    // }
    



    // //电机初始化
    // zdt_stepmot_init();
    // while(1)
    // {
    //     if(!zdt_stepmot_check())
    //     {
    //         //电机设置
    //         sp_uart_tx("st1\n");
    //         zdt_stepmot_set(1,400,800);
    //         sp_uart_tx("st2\n");
    //         zdt_stepmot_set(0,400,800);
    //     }else
    //     {
    //         sp_uart_tx("busy\n");
    //     }
    // }




    //云台初始化
    stepmot_pzt_init();

    // //正方形测试
    // while(1)
    // {
    //     if(!stepmot_pzt_check())
    //     {
    //         //云台设置
    //         sp_uart_tx("st1\n");
    //         // zdt_stepmot_set(1,400,800);
    //         // stepmot_pzt_set(1,50,100,1,50,100);
    //         stepmot_pzt_set(1,50,100,0,0,0);
    //         stepmot_pzt_set(0,0,0,1,50,100);
    //         // stepmot_pzt_set(1,200,1000,0,0,0);
    //         sp_uart_tx("st2\n");
    //         // zdt_stepmot_set(0,400,800);
    //         // stepmot_pzt_set(0,50,100,0,50,100);
    //         stepmot_pzt_set(0,50,100,0,0,0);
    //         stepmot_pzt_set(0,0,0,0,50,100);
    //         // stepmot_pzt_set(0,200,1000,0,0,0);
    //     }else
    //     {
    //         // sp_uart_tx("busy\n");
    //         osDelay(1);
    //     }
    // }



    // while(1)
    // {
    //     stepmot_pzt_set(100,-200,0,0);
    //     stepmot_pzt_set(0,0,100,-200);
    //     osDelay(1000);
    //     stepmot_pzt_reset();
    // }

    
    // while(1)
    // {
    //     stepmot_pzt_set_2(-100,0);
    //     stepmot_pzt_set_2(0,-100);
    //     osDelay(1000);
    //     stepmot_pzt_reset();
    // }


    // while(1)
    // {
    //     stepmot_pzt_draw(100,-50);
    //     osDelay(1000);
    //     stepmot_pzt_reset();
    //     osDelay(2000);

    // }




    float x=0;
    float y=sinf(x);
    float step=0.008;
    while(1)
    {
        if(x>M_PI*2)
        {
            step=-step;
        }
        if(x<0)
        {
            step=-step;
        }
        if(step>0)
        {
            y=sinf(x);
        }else
        {
            y=-sinf(x);
        }
        x+=step;
        stepmot_pzt_draw((i32)(20*x),(i32)(20*y));
        osDelay(1);
    }

}
